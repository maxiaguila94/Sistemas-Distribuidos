#include <stdio.h>
#include <stdlib.h>

int print_hola(void)
{
    return printf("Hola, mundo\n");
}

int main(void)
{
    int print_hola(void);

    if (print_hola() > 0)
        printf("Mision cumplida\n");
    else
        printf("Incapaz de mostrar mensaje\n");

    exit(0);
}
