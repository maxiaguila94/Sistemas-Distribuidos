/*
* physic.h
*/
int send_packet( const void *p, int qty );
int receive_packet( void *p, int lim );