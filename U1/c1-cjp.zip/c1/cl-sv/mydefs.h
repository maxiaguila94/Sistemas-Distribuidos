#ifndef __MYDEFS__
#define __MYDEFS__
#define forever for(;;)
#endif