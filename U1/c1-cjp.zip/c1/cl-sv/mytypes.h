#ifndef __MYTYPES__
#define __MYTYPES__

/*
 *	mytypes.h
 */

typedef short RINT_T;

#endif



